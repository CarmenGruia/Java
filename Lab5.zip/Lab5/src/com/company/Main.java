package com.company;

import java.io.IOException;
import java.util.Arrays;

/**
 * Class Main
 * [COMPULSORY]
 * @author Gruia Carmen
 */
public class Main {
    public static void main(String[] args) throws IOException {
        Catalog catalog = new Catalog("Documents");

        String name = catalog.getName();
        System.out.println(name);

        Document doc1=new Document("doc1.txt");
        Document doc2=new Document("doc2.txt");
        Document doc3=new Document("doc3.txt");
        Document doc4=new Document("doc4.txt");
        catalog.addDocument(doc1);
        System.out.println(catalog.l1);
        catalog.addDocument(doc2);
        catalog.addDocument(doc3);
        catalog.addDocument(doc4);
        System.out.println(catalog.l1);
        catalog.deleteDocument(doc3);
        System.out.println(catalog.l1);

        catalog.save();
        catalog.load();
        doc1.view();
        doc3.view();
    }
}