package com.company;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.*;
import java.io.*;

/**
 * Class Catalog
 * @author Gruia Carmen
 */
public class Catalog implements java.io.Serializable  {
    String name;

    List<String> l1=new ArrayList<String>();//lista de documente
    String filename = "file.txt";//fisierul in care se salveaza continutul catalogului

    /**
     * Constructor
     * @exception  FileNotFoundException .
     * @exception IOException on input error.
     */
    public Catalog(String name) throws FileNotFoundException, IOException {
        this.name=name;
    }


    public String getName()
    {
        return this.name;
    }

    /**
     * This method adds a document to this catalog.
     * @param document The one that we add.
     */
    void addDocument(Document document) {
       l1.add(document.getName());

    }

    /**
     * This method deletes a document from this catalog.
     * @param document The one that we want to delete.
     * @exception IndexOutOfBoundsException If the document that we want to delete does not exists in this catalog.
     */
    void deleteDocument(Document document)
    {

        try
        {
            int index=l1.indexOf(document.getName());
            l1.remove(index);

        }
        catch(IndexOutOfBoundsException e)
        {
            System.out.println("Documentul nu a fost in lista");
        }

    }

    /**
     * This method saves the content of the catalog (the list of documents) in an external file.
     * @exception IOException
     */
    void save()
    {
        try {
        //Saving of object in a file
        FileOutputStream file = new FileOutputStream(filename);
        ObjectOutputStream out = new ObjectOutputStream(file);

        // Method for serialization of object
        out.writeObject(l1);

        out.close();
        file.close();

        System.out.println("Object has been serialized");

    }

        catch(IOException ex)
        {
        System.out.println("IOException is caught");
    }

}

    /**
     * This method loads the content of the catalog from the saved file.
     * @throws IOException
     */
    void load() throws IOException {


        String content = new String(Files.readAllBytes(Paths.get(filename)));
        System.out.println(content);
    }
    }



