package com.company;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

/**
 * Class Document
 * @author Gruia Carmen
 */
public class Document {
    int ID;
    String name;

    /**
     * Constructor
     * @param name
     */
    public Document(String name)

    {
        this.name=name;
    }

    public String getName()
    {
        return this.name;
    }

    /**
     * This method allows you to view the contents of a document
     * @throws IOException
     */
    void view() throws IOException {
        String content = new String(Files.readAllBytes(Paths.get(name)));
        System.out.println(content);
    }
}
